import{n as e}from"./settings-D6v3PJfC.js";var t=`hackmdImageResize`,n=`data-hackmd-resize-overlay`,r=`hackmd-resize-active`,i=14,a=`[HackMD Resize Toolkit]`,o=[`.ui-view-area .markdown-body`,`.view-area .markdown-body`,`.markdown-body`],s=[`.ui-edit-area .CodeMirror`,`.CodeMirror`,`.CodeMirror-code`,`textarea`],c=/!\[[^\]]*\]\(([^\s)]+)(?:\s+=([^\s)]+))?\)/g,l=`hackmd-resize-toolkit-page-bridge`,u=`hackmd-resize-toolkit:request`,d=`hackmd-resize-toolkit:response`,f=!1,p=null,m=null,h=null,g={id:t,matches(e){return e.hostname===`hackmd.io`},run(e){h=e,L(`feature started`,e.features),_(),I(),v(e),y(e)},stop(){p?.disconnect(),p=null,b()}};function _(){if(f)return;let e=document.createElement(`style`);e.textContent=`
    [${n}] {
      position: absolute;
      inset: 0;
      pointer-events: none;
      z-index: 1;
      border: 1px solid rgba(124, 58, 237, 0.45);
      border-radius: 6px;
      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.08);
    }

    [${n}]::before {
      content: attr(data-label);
      position: absolute;
      top: 8px;
      left: 8px;
      padding: 2px 8px;
      border-radius: 999px;
      background: rgba(15, 23, 42, 0.85);
      color: #e2e8f0;
      font-size: 11px;
      line-height: 1.3;
      opacity: 0;
      transition: opacity 0.15s ease;
    }

    .hackmd-resize-wrapper:hover [${n}]::before,
    .${r} [${n}]::before {
      opacity: 1;
    }

    .hackmd-resize-wrapper {
      position: relative;
      display: inline-block;
      overflow: visible;
      vertical-align: top;
    }

    .hackmd-resize-wrapper img {
      display: block;
      max-width: none;
      height: auto;
    }

    .hackmd-resize-handle {
      position: absolute;
      right: -7px;
      bottom: -7px;
      width: ${i}px;
      height: ${i}px;
      border-radius: 999px;
      border: 2px solid #ffffff;
      background: #7c3aed;
      box-shadow: 0 4px 14px rgba(15, 23, 42, 0.35);
      cursor: nwse-resize;
      pointer-events: auto;
      z-index: 3;
      touch-action: none;
      user-select: none;
      -webkit-user-select: none;
    }

    .hackmd-resize-wrapper .hackmd-resize-handle {
      opacity: 1;
      transition: opacity 0.15s ease;
    }

    .hackmd-resize-wrapper:not([data-show-hint='true']) .hackmd-resize-handle,
    .hackmd-resize-wrapper:not([data-show-hint='true']) [data-hackmd-resize-overlay] {
      opacity: 0;
    }

    .hackmd-resize-wrapper:hover .hackmd-resize-handle,
    .${r} .hackmd-resize-handle {
      opacity: 1;
    }
  `,document.head.append(e),f=!0}function v(e){p&&p.disconnect(),p=new MutationObserver(()=>{y(h??e)}),p.observe(document.body,{childList:!0,subtree:!0})}function y(e){let t=C();if(!t){b(),L(`preview root not found`);return}let r=t.querySelectorAll(`img`),i=e.features.showResizeHints;L(`refresh`,{splitVisible:w(),imageCount:r.length,showHint:i}),r.forEach(e=>{if(e.closest(`.hackmd-resize-wrapper`)){let t=e.closest(`.hackmd-resize-wrapper`);t&&(t.dataset.showHint=String(i));return}let t=document.createElement(`span`);t.className=`hackmd-resize-wrapper`,t.dataset.showHint=String(i),e.parentNode?.insertBefore(t,e),t.append(e),k(e,t);let r=document.createElement(`span`);r.setAttribute(n,`true`),r.setAttribute(`data-label`,`拖曳右下角以調整寬度`);let a=document.createElement(`button`);a.type=`button`,a.className=`hackmd-resize-handle`,a.title=`拖曳調整圖片大小`,a.addEventListener(`pointerdown`,n=>{x(n,e,t)}),t.append(r,a)})}function b(){document.querySelectorAll(`.hackmd-resize-wrapper`).forEach(e=>{let t=e.querySelector(`img`);if(!t||!e.parentNode){e.remove();return}e.parentNode.insertBefore(t,e),e.remove()})}function x(e,t,n){e.preventDefault(),e.stopPropagation();let i=t.currentSrc||t.getAttribute(`src`)||``,a=i?E(i):Promise.resolve(null),o={lastAppliedWidth:null,patchTarget:null,snapshot:null};a.then(e=>{o.snapshot=e,o.patchTarget=e?.match??null}),L(`pointerdown`,{imageUrl:i}),k(t,n);let s=t.getBoundingClientRect(),c=e.clientX,l=s.width;n.classList.add(r);let u=s.width>0?s.height/s.width:A(t),d=e=>{n.style.width=`${e}px`,n.style.height=`${Math.round(e*u)}px`,t.style.width=`100%`,t.style.height=`100%`,t.style.maxWidth=`none`,t.style.objectFit=`fill`,t.style.display=`block`};d(l);let f=e=>{let t=e.clientX-c,r=M(Math.round(l+t),40,Math.round(s.width*4));d(r),S(n,`${r}px`),o.lastAppliedWidth=r},p=async()=>{if(n.classList.remove(r),o.lastAppliedWidth===null){window.removeEventListener(`pointermove`,f),window.removeEventListener(`pointerup`,p);return}o.lastAppliedWidth!==null&&d(o.lastAppliedWidth),o.patchTarget&&o.lastAppliedWidth!==null?await P(o.patchTarget.start,o.patchTarget.end,j(o.patchTarget,o.lastAppliedWidth))?S(n,`${o.lastAppliedWidth}px 已寫回 markdown`):S(n,`${o.lastAppliedWidth}px（無法寫回）`):o.lastAppliedWidth!==null&&S(n,`${o.lastAppliedWidth}px（僅預覽，尚未寫回）`),window.removeEventListener(`pointermove`,f),window.removeEventListener(`pointerup`,p)};window.addEventListener(`pointermove`,f),window.addEventListener(`pointerup`,p,{once:!0})}function S(e,t){e.querySelector(`[${n}]`)?.setAttribute(`data-label`,t)}function C(){for(let e of o){let t=document.querySelector(e);if(t)return t}return null}function w(){let e=C(),t=s.map(e=>document.querySelector(e)).find(e=>!!e);return!e||!t?!1:T(e)&&T(t)}function T(e){let t=e.getBoundingClientRect(),n=window.getComputedStyle(e);return t.width>0&&t.height>0&&n.display!==`none`&&n.visibility!==`hidden`}async function E(e){let t=await N();return t?{markdown:t,match:D(t,e)}:null}function D(e,t){for(let n of e.matchAll(c)){let e=n[0],r=n[1];if(O(r,t))return{fullMatch:e,imageUrl:r,sizeToken:n[2],start:n.index??0,end:(n.index??0)+e.length}}return null}function O(e,t){if(e===t)return!0;try{return new URL(e,window.location.href).toString()===new URL(t,window.location.href).toString()}catch{return!1}}function k(e,t){let n=e.getBoundingClientRect(),r=n.width||e.width||e.naturalWidth,i=n.height||e.height||e.naturalHeight;r>0&&(t.style.width=`${r}px`),i>0&&(t.style.height=`${i}px`),e.style.width=`100%`,e.style.height=`100%`,e.style.maxWidth=`none`,e.style.objectFit=`fill`,e.style.display=`block`}function A(e){let t=e.naturalWidth||e.width||1;return(e.naturalHeight||e.height||1)/t}function j(e,t){return e.sizeToken?e.fullMatch.replace(`=${e.sizeToken}`,`=${t}x`):e.fullMatch.replace(`(${e.imageUrl})`,`(${e.imageUrl} =${t}x)`)}function M(e,t,n){return Math.max(t,Math.min(n,e))}async function N(){let e=await F(`getMarkdown`);return typeof e==`string`?e:``}async function P(e,t,n){return await F(`replaceRange`,{end:t,start:e,text:n})===!0}async function F(e,t){await I();let n=crypto.randomUUID();return new Promise((r,i)=>{let a=window.setTimeout(()=>{o(),i(Error(`Page bridge timeout for ${e}`))},2e3),o=()=>{window.clearTimeout(a),document.removeEventListener(d,s)},s=t=>{let a=t;a.detail?.id===n&&(o(),a.detail.ok?r(a.detail.result):i(Error(a.detail.error||`Page bridge failed for ${e}`)))};document.addEventListener(d,s),document.dispatchEvent(new CustomEvent(u,{detail:{id:n,payload:t,type:e}}))})}function I(){return m||(m=new Promise((e,t)=>{let n=document.getElementById(l);if(n?.dataset.loaded===`true`){e();return}let r=n??document.createElement(`script`);r.id=l,r.src=chrome.runtime.getURL(`page-bridge.js`),r.addEventListener(`load`,()=>{r.dataset.loaded=`true`,e()},{once:!0}),r.addEventListener(`error`,()=>{t(Error(`Failed to inject page bridge`))},{once:!0}),n||(document.head||document.documentElement).append(r)}),m)}function L(e,t){console.debug(a,e,t)}var R=[g],z=new Map;async function B(e){for(let t of R)if(t.matches(window.location)){if(e.features[t.id]){t.run(e),z.set(t.id,t);continue}z.has(t.id)&&(t.stop?.(),z.delete(t.id))}}function V(e){let t=e??(globalThis.location===void 0?``:globalThis.location.href);return/^https:\/\/hackmd\.io\//.test(t)}async function H(){await B(await e())}async function U(){V()&&(await H(),chrome.storage.onChanged.addListener((e,t)=>{t!==`sync`||!e.settings||H()}))}U();